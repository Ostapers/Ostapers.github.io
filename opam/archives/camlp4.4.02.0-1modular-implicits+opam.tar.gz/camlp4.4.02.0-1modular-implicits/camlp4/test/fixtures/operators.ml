let _ : int = 42
let (+) = M.(+)
let (+) = M.(+) in 42
let (+) : int -> int -> int = (+)
let (+) : int -> int -> int = (+) in 42
let None = None
let None : int option = None
