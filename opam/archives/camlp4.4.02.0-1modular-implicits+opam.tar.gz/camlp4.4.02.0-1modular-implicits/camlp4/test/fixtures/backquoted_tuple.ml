EXTEND Gram
  abc: [ [ `(A,y) -> y ] ];
END;
