value f = fun [];
value f = fun [ [] -> fun [ 4 -> () ] ];
value f = fun [];
value f = fun [];
value f = fun [];
value f = g x y;
value f = (g x) y;
