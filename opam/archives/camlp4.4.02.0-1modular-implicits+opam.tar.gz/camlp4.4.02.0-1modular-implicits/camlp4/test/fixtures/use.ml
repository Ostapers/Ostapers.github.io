(* use.ml *)
#use "test/fixtures/rec.ml";
(* value use *)
value use = 3;
