(* rec.ml *)
value rec x = 42;
