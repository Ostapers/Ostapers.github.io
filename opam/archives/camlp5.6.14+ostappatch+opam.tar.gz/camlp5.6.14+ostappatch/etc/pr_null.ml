(* camlp5r *)
(* pr_null.ml,v *)
(* Copyright (c) INRIA 2007-2014 *)

Pcaml.print_interf.val := fun _ -> ();
Pcaml.print_implem.val := fun _ -> ();
