LOG[view1] (Printf.printf "test log message\n");;

let _ = REPR (1);;


