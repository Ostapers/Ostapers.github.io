LOG[view1] (Printf.printf "test log message\n");
