#!/bin/sh -e

COMM=${OCAMLN}opt$OPT
echo $COMM $*
$COMM $*
