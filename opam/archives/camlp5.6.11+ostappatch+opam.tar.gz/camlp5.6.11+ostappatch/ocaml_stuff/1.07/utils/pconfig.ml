let ocaml_version = "1.07"
let ocaml_name = "ocaml"
let ast_impl_magic_number = "Caml1999M004"
let ast_intf_magic_number = "Caml1999N004"
